ANIMATING HUMAN WALKING
Caltech CS 174 Project
by Shang-Lin Chen

Program Instructions
-----------------------------

Animation starts automatically.

MODES:
3D mode - Torso, arms, and legs are rendered as 3D rectangular solids.
Stick mode - Stick person.

Full body mode - Legs, arms, torso, and head are all drawn.
Legs only mode - Self-explanatory.

KEY BINDINGS
F1 - Switches between 3D mode and stick mode.

F2 - Switches between full body mode and legs only mode. Pressing
     F2 again switches back.

p - Pauses animation. Pressing 'p' again resumes animation.
